# Zefari (Fabric 1.21.1)

Derleme: repoyu GitHub'a yukle -> Actions sekmesi -> "build" -> Artifacts -> Zefari (jar).
Yerelde: `gradle build` (Java 21, Gradle 8.10+). Jar: build/libs/zefari-1.0.0.jar
Gerekli: Fabric Loader 0.16+, Fabric API 0.102.0+1.21.1
Menu: Right Shift.

## Yeni (v1.1)
- Social paneli (ClickGUI'nin sagi): Configs + Friends. Config dosyalari: .minecraft/config/zefari/configs/*.json
  Arkadasla paylasma: dosyayi gonder ya da "Export" (panoya kod) -> arkadas "Import" (panodan kod).
- Friends: isim yazip Add Friend (Enter). Aura arkadaslara kitlenmez/vurmaz.
- Aura: Aim Range (1-100), sessiz rotasyon (kamera donmez, sadece karakter/sunucu rotasyonu).
- Auto Totem (Combat), Hand Animations (Render): Spin / Karambit / Nurik.
