package com.zefari.util;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Arkadas listesi. Aura arkadaslara vurmaz / kitlenmez. Dosya: config/zefari/friends.txt */
public final class Friends {
    private static final Map<String, String> FRIENDS = new LinkedHashMap<>();

    private Friends() {}

    private static Path file() {
        Path d = FabricLoader.getInstance().getConfigDir().resolve("zefari");
        try { Files.createDirectories(d); } catch (IOException ignored) {}
        return d.resolve("friends.txt");
    }

    public static boolean valid(String name) {
        return name != null && name.matches("[A-Za-z0-9_]{1,16}");
    }

    public static boolean isFriend(String name) {
        return name != null && FRIENDS.containsKey(name.toLowerCase(Locale.ROOT));
    }

    public static boolean add(String name) {
        if (name == null) return false;
        name = name.trim();
        if (!valid(name)) return false;
        FRIENDS.put(name.toLowerCase(Locale.ROOT), name);
        save();
        return true;
    }

    public static void remove(String name) {
        if (name == null) return;
        FRIENDS.remove(name.toLowerCase(Locale.ROOT));
        save();
    }

    public static List<String> list() { return new ArrayList<>(FRIENDS.values()); }

    public static void load() {
        FRIENDS.clear();
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            for (String line : Files.readAllLines(f)) {
                line = line.trim();
                if (valid(line)) FRIENDS.put(line.toLowerCase(Locale.ROOT), line);
            }
        } catch (IOException ignored) {}
    }

    private static void save() {
        try { Files.write(file(), new ArrayList<>(FRIENDS.values())); } catch (IOException ignored) {}
    }
}
