package com.zefari.util;

public final class TpsTracker {
    private static long last = -1;
    private static double tps = 20.0;

    public static void onTimeUpdate() {
        long now = System.nanoTime();
        if (last > 0) {
            double dt = (now - last) / 1.0e9;
            if (dt > 0.1) {
                double inst = Math.min(20.0, 20.0 / dt);
                tps = tps * 0.7 + inst * 0.3;
            }
        }
        last = now;
    }

    public static void reset() { last = -1; tps = 20.0; }
    public static double get() { return tps; }
}
