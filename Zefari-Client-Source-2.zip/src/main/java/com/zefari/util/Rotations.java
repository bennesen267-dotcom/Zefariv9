package com.zefari.util;

/**
 * Sessiz (silent) rotasyon: Aura'nin baktigi yon. Kamera (oyuncunun ekrani) DONMEZ,
 * sadece sunucuya giden paketlerde ve 3. sahis karakter modelinde bu yon kullanilir.
 */
public final class Rotations {
    public static boolean active;
    public static float yaw, pitch, prevYaw, prevPitch;

    private Rotations() {}

    /** Hedef ilk bulundugunda kameranin bulundugu yonden baslar. */
    public static void begin(float y, float p) {
        yaw = prevYaw = y;
        pitch = prevPitch = p;
        active = true;
    }

    public static void set(float y, float p) {
        prevYaw = yaw;
        prevPitch = pitch;
        yaw = y;
        pitch = p;
        active = true;
    }

    public static void clear() { active = false; }
}
