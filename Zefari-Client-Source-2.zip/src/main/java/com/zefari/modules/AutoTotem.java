package com.zefari.modules;

import com.zefari.module.Category;
import com.zefari.module.Module;
import com.zefari.setting.Setting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** Offhand'de totem yoksa envanterden totemi offhand'e koyar (totem patlayinca da yeniler). */
public class AutoTotem extends Module {
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 1, 0, 10));
    public final Setting.Num health = add(new Setting.Num("Health", 20, 1, 20));
    public final Setting.Bool hotbarOnly = add(new Setting.Bool("Hotbar Only", false));

    private int cooldown;

    public AutoTotem() { super("Auto Totem", Category.COMBAT); }

    @Override public void onDisable() { cooldown = 0; }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || !p.isAlive()) return;
        if (cooldown > 0) { cooldown--; return; }
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        if (p.getHealth() > health.value) return;
        // Baska bir konteyner (sandik vb.) aciksa syncId 0 islemleri calismaz
        if (p.currentScreenHandler != p.playerScreenHandler) return;

        int limit = hotbarOnly.value ? 9 : 36;
        for (int i = 0; i < limit; i++) {
            if (!p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) continue;
            int slotId = i < 9 ? i + 36 : i; // hotbar 36-44, ana envanter 9-35
            // SWAP + buton 40 = secilen slotu offhand ile degistir
            mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slotId, 40, SlotActionType.SWAP, p);
            cooldown = (int) delay.value;
            return;
        }
    }
}
