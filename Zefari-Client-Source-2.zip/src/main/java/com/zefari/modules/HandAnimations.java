package com.zefari.modules;

import com.zefari.module.Category;
import com.zefari.module.Module;
import com.zefari.setting.Setting;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/** Birinci sahis kilic animasyonlari (HeldItemRendererMixin cagirir). Sadece gorsel, client-side. */
public class HandAnimations extends Module {
    public final Setting.Mode mode = add(new Setting.Mode("Mode", "Spin", "Karambit", "Nurik"));

    public HandAnimations() { super("Hand Animations", Category.RENDER); }

    /** swing: 0 = vurmuyor, 0..1 = vurus ilerlemesi. */
    public void apply(AbstractClientPlayerEntity pl, Hand hand, float swing, ItemStack stack, MatrixStack ms) {
        if (!(stack.getItem() instanceof SwordItem) && !(stack.getItem() instanceof AxeItem)) return;

        Arm arm = hand == Hand.MAIN_HAND ? pl.getMainArm() : pl.getMainArm().getOpposite();
        float side = arm == Arm.RIGHT ? 1f : -1f;
        float s = MathHelper.clamp(swing, 0f, 1f);
        float e = s * s * (3f - 2f * s); // smoothstep
        float pi = (float) Math.PI;

        // Itemin eldeki yerine tasi, orada don, geri tasi
        ms.translate(side * 0.56f, -0.52f, -0.72f);

        if (mode.is("Spin")) {
            // Vurunca kilic 360 derece doner
            if (s > 0f) ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-side * 360f * e));
        } else if (mode.is("Karambit")) {
            // Ters tutus (karambit gibi) + vurunca havali cift takla
            ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-side * 22f));
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 12f));
            if (s > 0f) {
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-720f * e));
                ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * 28f * (float) Math.sin(pi * s)));
            }
        } else {
            // Nurik: vurunca cok hafif sarsilma
            if (s > 0f) {
                float k = 1f - s;
                ms.translate(side * (float) Math.sin(s * pi * 10f) * 0.006f * k,
                        (float) Math.cos(s * pi * 9f) * 0.006f * k, 0f);
                ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * (float) Math.sin(s * pi * 8f) * 2.2f * k));
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) Math.cos(s * pi * 7f) * 1.5f * k));
            }
        }

        ms.translate(-side * 0.56f, 0.52f, 0.72f);
    }
}
