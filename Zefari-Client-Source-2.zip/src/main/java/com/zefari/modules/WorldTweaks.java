package com.zefari.modules;

import com.zefari.module.Category;
import com.zefari.module.Module;
import com.zefari.setting.Setting;
import net.minecraft.util.math.MathHelper;

/** Gorus mesafesi sinirinda secilen renkte sis (BackgroundRendererMixin). */
public class WorldTweaks extends Module {
    public final Setting.Num hue = add(new Setting.Num("Hue", 0.8, 0, 1));
    public final Setting.Num sat = add(new Setting.Num("Saturation", 0.6, 0, 1));
    public final Setting.Num bri = add(new Setting.Num("Brightness", 0.6, 0, 1));

    public WorldTweaks() {
        super("World Tweaks", Category.RENDER);
        add(new Setting.Swatch("Color", this::color));
    }

    public int color() {
        return MathHelper.hsvToRgb((float) hue.value, (float) sat.value, (float) bri.value) & 0xFFFFFF;
    }
}
