package com.zefari.modules;

import com.zefari.module.Category;
import com.zefari.module.Module;
import com.zefari.setting.Setting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;

public class ElyHelper extends Module {
    public final Setting.Mode mode = add(new Setting.Mode("Mode", "Normal", "Silent"));
    public final Setting.Num delay = add(new Setting.Num("Delay (ms)", 1500, 100, 5000));

    private long last;
    private int restoreSlot = -1;
    private static int restoreTicks;

    public ElyHelper() { super("Ely Helper", Category.MISC); }

    /** Aura ile uyum: fisek islemi suruyorsa Aura slot degistirmez / vurmaz. */
    public static boolean isBusy() { return restoreTicks > 0; }

    @Override public void onDisable() { restoreTicks = 0; restoreSlot = -1; }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        PlayerInventory inv = p.getInventory();

        if (restoreTicks > 0) {
            restoreTicks--;
            if (restoreTicks == 0 && restoreSlot >= 0) {
                inv.selectedSlot = restoreSlot;
                restoreSlot = -1;
            }
            return;
        }

        if (!p.isFallFlying()) return;
        long now = System.currentTimeMillis();
        if (now - last < (long) delay.value) return;

        // Offhand'de fisek varsa direkt kullan (slot degismez)
        if (p.getOffHandStack().isOf(Items.FIREWORK_ROCKET)) {
            mc.interactionManager.interactItem(p, Hand.OFF_HAND);
            last = now;
            return;
        }

        int slot = -1;
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isOf(Items.FIREWORK_ROCKET)) { slot = i; break; }
        }
        if (slot < 0) return;

        int cur = inv.selectedSlot;
        if (slot == cur) {
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        } else if (mode.is("Silent")) {
            // Elindeki slot ayni kalir, sunucuya gecici olarak fisek slotu bildirilir
            inv.selectedSlot = slot;
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            inv.selectedSlot = cur;
            p.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(cur));
        } else {
            inv.selectedSlot = slot;
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            restoreSlot = cur;
            restoreTicks = 3;
        }
        last = now;
    }
}
