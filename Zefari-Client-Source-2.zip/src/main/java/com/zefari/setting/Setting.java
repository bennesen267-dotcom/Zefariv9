package com.zefari.setting;

import java.util.function.IntSupplier;

public abstract class Setting {
    public final String name;

    protected Setting(String name) { this.name = name; }

    public static class Bool extends Setting {
        public boolean value;
        public Bool(String name, boolean value) { super(name); this.value = value; }
        public void toggle() { value = !value; }
    }

    /** Kaydirmali sayi ayari (2.34 gibi ondalikli). */
    public static class Num extends Setting {
        public final double min, max;
        public double value;
        public Num(String name, double value, double min, double max) {
            super(name); this.value = value; this.min = min; this.max = max;
        }
        public double ratio() { return (value - min) / (max - min); }
        public void setFromRatio(double r) {
            r = Math.max(0, Math.min(1, r));
            value = Math.round((min + (max - min) * r) * 100.0) / 100.0;
        }
        public float f() { return (float) value; }
    }

    public static class Mode extends Setting {
        public final String[] modes;
        public int index;
        public Mode(String name, String... modes) { super(name); this.modes = modes; }
        public String get() { return modes[index]; }
        public boolean is(String s) { return modes[index].equalsIgnoreCase(s); }
        public void next() { index = (index + 1) % modes.length; }
        public void prev() { index = (index - 1 + modes.length) % modes.length; }
    }

    public static class Label extends Setting {
        public Label(String name) { super(name); }
    }

    public static class Swatch extends Setting {
        public final IntSupplier color;
        public Swatch(String name, IntSupplier color) { super(name); this.color = color; }
    }
}
