package com.zefari;

import com.zefari.gui.ClickGuiScreen;
import com.zefari.module.Module;
import com.zefari.module.ModuleManager;
import com.zefari.util.Friends;
import com.zefari.util.Rotations;
import com.zefari.util.TpsTracker;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ZefariClient implements ClientModInitializer {
    private boolean wasDown;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        Friends.load();
        MinecraftClient mc = MinecraftClient.getInstance();

        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            boolean down = client.getWindow() != null
                    && InputUtil.isKeyPressed(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT);
            if (down && !wasDown && client.currentScreen == null && client.player != null) {
                client.setScreen(new ClickGuiScreen());
            }
            wasDown = down;

            if (client.player == null || client.world == null) return;
            for (Module m : ModuleManager.all()) if (m.enabled) m.onTick();
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            for (Module m : ModuleManager.all()) if (m.enabled) m.onHudRender(ctx);
        });

        WorldRenderEvents.LAST.register(context -> {
            if (context.matrixStack() == null) return;
            float td = mc.getRenderTickCounter().getTickDelta(false);
            var cam = mc.gameRenderer.getCamera().getPos();
            for (Module m : ModuleManager.all()) if (m.enabled) m.onWorldRender(context.matrixStack(), td, cam);
        });

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> { TpsTracker.reset(); Rotations.clear(); });
    }
}
