package com.zefari.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.zefari.module.Module;
import com.zefari.module.ModuleManager;
import com.zefari.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

/**
 * Config sistemi. Dosyalar: .minecraft/config/zefari/configs/<isim>.json
 * Arkadasla paylasmak icin: dosyayi gonder VEYA "Export" ile panoya kopyalanan kodu gonder, o da "Import" yapsin.
 */
public final class ConfigManager {
    private static final Gson PRETTY = new GsonBuilder().setPrettyPrinting().create();
    private static final Gson COMPACT = new Gson();
    public static final String PREFIX = "ZEFARI1:";

    private ConfigManager() {}

    public static Path dir() {
        Path d = FabricLoader.getInstance().getConfigDir().resolve("zefari").resolve("configs");
        try { Files.createDirectories(d); } catch (IOException ignored) {}
        return d;
    }

    public static String clean(String n) {
        if (n == null) return "default";
        n = n.trim().replaceAll("[^A-Za-z0-9_-]", "_");
        if (n.length() > 24) n = n.substring(0, 24);
        return n.isEmpty() ? "default" : n;
    }

    /** Su anki tum modul/ayar durumu. */
    public static JsonObject snapshot() {
        JsonObject root = new JsonObject();
        root.addProperty("client", "Zefari");
        root.addProperty("version", 1);
        JsonObject mods = new JsonObject();
        for (Module m : ModuleManager.all()) {
            JsonObject mo = new JsonObject();
            if (m.canToggle()) mo.addProperty("enabled", m.enabled);
            JsonObject so = new JsonObject();
            for (Setting s : m.settings) {
                if (s instanceof Setting.Bool b) so.addProperty(b.name, b.value);
                else if (s instanceof Setting.Num n) so.addProperty(n.name, n.value);
                else if (s instanceof Setting.Mode md) so.addProperty(md.name, md.get());
            }
            mo.add("settings", so);
            mods.add(m.name, mo);
        }
        root.add("modules", mods);
        return root;
    }

    public static boolean apply(JsonObject root) {
        try {
            if (root == null || !root.has("modules") || !root.get("modules").isJsonObject()) return false;
            JsonObject mods = root.getAsJsonObject("modules");
            for (Module m : ModuleManager.all()) {
                if (!mods.has(m.name) || !mods.get(m.name).isJsonObject()) continue;
                JsonObject mo = mods.getAsJsonObject(m.name);
                JsonObject so = mo.has("settings") && mo.get("settings").isJsonObject()
                        ? mo.getAsJsonObject("settings") : new JsonObject();
                for (Setting s : m.settings) {
                    if (!so.has(s.name)) continue;
                    JsonElement el = so.get(s.name);
                    if (s instanceof Setting.Bool b) {
                        b.value = el.getAsBoolean();
                    } else if (s instanceof Setting.Num n) {
                        n.value = Math.max(n.min, Math.min(n.max, el.getAsDouble()));
                    } else if (s instanceof Setting.Mode md) {
                        String want = el.getAsString();
                        for (int i = 0; i < md.modes.length; i++) {
                            if (md.modes[i].equalsIgnoreCase(want)) { md.index = i; break; }
                        }
                    }
                }
                if (m.canToggle() && mo.has("enabled")) m.setEnabled(mo.get("enabled").getAsBoolean());
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean save(String name) {
        try {
            Files.writeString(dir().resolve(clean(name) + ".json"), PRETTY.toJson(snapshot()), StandardCharsets.UTF_8);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public static boolean load(String name) {
        try {
            Path f = dir().resolve(clean(name) + ".json");
            if (!Files.exists(f)) return false;
            JsonObject o = JsonParser.parseString(Files.readString(f, StandardCharsets.UTF_8)).getAsJsonObject();
            return apply(o);
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean delete(String name) {
        try {
            return Files.deleteIfExists(dir().resolve(clean(name) + ".json"));
        } catch (IOException e) {
            return false;
        }
    }

    public static List<String> list() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> st = Files.list(dir())) {
            st.map(p -> p.getFileName().toString())
              .filter(n -> n.endsWith(".json"))
              .forEach(n -> out.add(n.substring(0, n.length() - 5)));
        } catch (IOException ignored) {}
        Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
        return out;
    }

    /** Su anki ayarlari paylasilabilir tek satirlik koda cevirir. */
    public static String export() {
        String json = COMPACT.toJson(snapshot());
        return PREFIX + Base64.getUrlEncoder().withoutPadding().encodeToString(json.getBytes(StandardCharsets.UTF_8));
    }

    /** Export kodu (veya ham JSON) alip ayarlari uygular. */
    public static boolean importString(String s) {
        try {
            if (s == null) return false;
            s = s.trim();
            String json;
            if (s.startsWith(PREFIX)) {
                json = new String(Base64.getUrlDecoder().decode(s.substring(PREFIX.length()).trim()), StandardCharsets.UTF_8);
            } else if (s.startsWith("{")) {
                json = s;
            } else {
                return false;
            }
            return apply(JsonParser.parseString(json).getAsJsonObject());
        } catch (Exception e) {
            return false;
        }
    }
}
