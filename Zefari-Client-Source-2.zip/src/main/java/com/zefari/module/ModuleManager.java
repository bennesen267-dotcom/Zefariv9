package com.zefari.module;

import com.zefari.modules.*;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    public static Aura aura;
    public static AutoTotem autoTotem;
    public static HandAnimations handAnimations;
    public static ElyHelper elyHelper;
    public static TargetEsp targetEsp;
    public static ItemFov itemFov;
    public static WorldTweaks worldTweaks;
    public static ClickGuiModule clickGui;
    public static HudModule hud;

    public static void init() {
        aura = reg(new Aura());
        autoTotem = reg(new AutoTotem());
        targetEsp = reg(new TargetEsp());
        itemFov = reg(new ItemFov());
        handAnimations = reg(new HandAnimations());
        worldTweaks = reg(new WorldTweaks());
        elyHelper = reg(new ElyHelper());
        clickGui = reg(new ClickGuiModule());
        hud = reg(new HudModule());
    }

    private static <T extends Module> T reg(T m) { MODULES.add(m); return m; }

    public static List<Module> all() { return MODULES; }

    public static List<Module> in(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.category == c) out.add(m);
        return out;
    }
}
