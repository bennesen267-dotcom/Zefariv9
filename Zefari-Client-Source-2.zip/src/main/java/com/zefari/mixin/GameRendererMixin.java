package com.zefari.mixin;

import com.zefari.module.ModuleManager;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    /** changingFov=false sadece el/item cizimi icin kullanilir -> sadece item FOV'u degisir. */
    @Inject(method = "getFov", at = @At("HEAD"), cancellable = true)
    private void zefari$itemFov(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Double> cir) {
        if (!changingFov && ModuleManager.itemFov != null && ModuleManager.itemFov.enabled) {
            cir.setReturnValue(ModuleManager.itemFov.fov.value);
        }
    }
}
