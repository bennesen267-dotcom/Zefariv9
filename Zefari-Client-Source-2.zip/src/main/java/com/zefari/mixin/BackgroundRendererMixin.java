package com.zefari.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import com.zefari.module.ModuleManager;
import com.zefari.modules.WorldTweaks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.CameraSubmersionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BackgroundRenderer.class)
public class BackgroundRendererMixin {
    @Inject(method = "applyFog", at = @At("TAIL"))
    private static void zefari$fog(CallbackInfo ci) {
        WorldTweaks wt = ModuleManager.worldTweaks;
        if (wt == null || !wt.enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.gameRenderer == null || mc.gameRenderer.getCamera() == null) return;
        if (mc.gameRenderer.getCamera().getSubmersionType() != CameraSubmersionType.NONE) return;

        float start = RenderSystem.getShaderFogStart();
        float end = RenderSystem.getShaderFogEnd();
        if (start <= 0f) return; // gokyuzu sisi, dokunma

        int rgb = wt.color();
        RenderSystem.setShaderFogStart(end * 0.55f);
        RenderSystem.setShaderFogColor(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, 1f);
    }
}
