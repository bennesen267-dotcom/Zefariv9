package com.zefari.mixin;

import com.zefari.util.Rotations;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hareket paketi gonderilirken yaw/pitch'i gecici olarak Aura'nin sessiz rotasyonuna cevirir; kamera degismez. */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    @Unique private float zefari$yaw, zefari$pitch;
    @Unique private boolean zefari$swapped;

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void zefari$before(CallbackInfo ci) {
        if (!Rotations.active) return;
        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        zefari$yaw = self.getYaw();
        zefari$pitch = self.getPitch();
        self.setYaw(Rotations.yaw);
        self.setPitch(Rotations.pitch);
        zefari$swapped = true;
    }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"))
    private void zefari$after(CallbackInfo ci) {
        if (!zefari$swapped) return;
        zefari$swapped = false;
        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        self.setYaw(zefari$yaw);
        self.setPitch(zefari$pitch);
    }
}
