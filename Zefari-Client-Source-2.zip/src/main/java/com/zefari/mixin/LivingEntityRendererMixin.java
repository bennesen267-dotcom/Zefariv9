package com.zefari.mixin;

import com.zefari.util.Rotations;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 3. sahis gorunumde karakter modeli Aura'nin hedefine bakar (kamera donmez). */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @Unique private float zefari$hy, zefari$phy, zefari$by, zefari$pby, zefari$p, zefari$pp;
    @Unique private boolean zefari$on;

    @Inject(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"))
    private void zefari$before(LivingEntity e, float yaw, float tickDelta, MatrixStack ms,
                               VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        zefari$on = false;
        if (!Rotations.active || e != MinecraftClient.getInstance().player) return;
        zefari$on = true;
        zefari$hy = e.headYaw; zefari$phy = e.prevHeadYaw;
        zefari$by = e.bodyYaw; zefari$pby = e.prevBodyYaw;
        zefari$p = e.getPitch(); zefari$pp = e.prevPitch;

        float y = MathHelper.lerpAngleDegrees(tickDelta, Rotations.prevYaw, Rotations.yaw);
        float p = MathHelper.lerp(tickDelta, Rotations.prevPitch, Rotations.pitch);
        e.headYaw = y; e.prevHeadYaw = y;
        e.bodyYaw = y; e.prevBodyYaw = y;
        e.setPitch(p); e.prevPitch = p;
    }

    @Inject(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("RETURN"))
    private void zefari$after(LivingEntity e, float yaw, float tickDelta, MatrixStack ms,
                              VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        if (!zefari$on) return;
        zefari$on = false;
        e.headYaw = zefari$hy; e.prevHeadYaw = zefari$phy;
        e.bodyYaw = zefari$by; e.prevBodyYaw = zefari$pby;
        e.setPitch(zefari$p); e.prevPitch = zefari$pp;
    }
}
